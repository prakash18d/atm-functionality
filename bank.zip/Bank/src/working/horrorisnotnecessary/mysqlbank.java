package working.horrorisnotnecessary;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class mysqlbank implements AccountInfo {

	
	public int getAccount(Account x) 
	{
		// TODO Auto-generated method stub
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/world","root","cdacacts");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		System.out.println("connected to data base for prepared statement");
		
		String q3 = "select * from account where acc_no = ?";
		
		//update emp set sal = sal + ? where empno = ?
		
		PreparedStatement psmt = null;
		try {
			psmt = con.prepareStatement(q3);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		    try {
				psmt.setInt(1, x.getAccountNumber());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		    ResultSet rs = null;
			try {
				rs = psmt.executeQuery();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		    
		    try {
				rs.next();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    Account c=null;
		    try {
				c=new Account(rs.getInt(1), rs.getInt(2), rs.getInt(3));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    			
    		
		    if( c != null)
			{		
					if(c.validatePIN(x.getPin()))
					{
						
						x.setTotalBalance(c.getTotalBalance());
						return 2; //everything is ok
						
					}
				
			}
			
			return 1;
	}

	@Override
	public boolean updateAccount(Account x) {
		
		// TODO Auto-generated method stub
				Connection con = null;
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/world","root","cdacacts");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				System.out.println("connected to data base for prepared statement");
				
				String q3 = "update account set balance=? where acc_no=?";
				
			
				
				PreparedStatement psmt = null;
				try {
					psmt = con.prepareStatement(q3);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
				    try {
						psmt.setDouble(1, x.getTotalBalance());
						psmt.setInt(2, x.getAccountNumber());
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				   
					try {
						 psmt.executeUpdate();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				    
				    
				   
				   
		    			
		    		
				 
		// TODO Auto-generated method stub
		return true;
	}

	

}
